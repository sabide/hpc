# Configuration

To run the TPs, it is necessary to create a file make_inc in the `arch`
directory.
The simplest way is to create a symbolic link to one of the already defined
`make_xxx` files.