#ifndef COMPUTE_H
#define COMPUTE_H

void initialization(double **, double **, double **);
void computation(double *, double *);
void output_results(double *, double *);

#endif
