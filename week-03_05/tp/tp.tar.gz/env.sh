module load intel/2025.2.0 impi/2021.16
export PYTHONUSERBASE=/workspace/mpi/2026/python_pkgs
